from bpsymbol.symbol import Symbol

if __name__ == '__main__':
    print(Symbol(symbol='005380 KS Equity', base='bloomberg').use('yahoo'))

